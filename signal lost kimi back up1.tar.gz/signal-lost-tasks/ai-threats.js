/**
 * Signal Lost — AI Threats System
 * Patrol drones, sniper nests, environmental hazards
 */

(function() {
  'use strict';

  // ============ CONFIG ============
  const DRONE_SPEED = 0.00005; // degrees per tick (~5m/s)
  const DRONE_SPOT_RADIUS = 80; // meters
  const DRONE_ALERT_RANGE = 500; // meters broadcast to enemies
  const SNIPER_RANGE = 200; // meters
  const SNIPER_COOLDOWN = 8000; // ms between shots

  // ============ DRONE PATROL SYSTEM ============
  class PatrolDrone {
    constructor(id, waypoints, map) {
      this.id = id;
      this.waypoints = waypoints; // array of [lat, lng]
      this.currentIndex = 0;
      this.map = map;
      this.spotted = []; // players currently spotted
      this.alerted = false;
      this.direction = 1; // 1 = forward, -1 = reverse

      // Create marker
      this.marker = L.marker(this.waypoints[0], {
        icon: L.divIcon({
          className: 'patrol-drone',
          html: '🛸',
          iconSize: [32, 32],
          iconAnchor: [16, 16]
        })
      }).addTo(map);

      // Create searchlight cone (circle)
      this.spotlight = L.circle(this.waypoints[0], {
        radius: DRONE_SPOT_RADIUS,
        color: '#df1f2d',
        fillColor: '#df1f2d',
        fillOpacity: 0.15,
        weight: 1,
        dashArray: '4 4'
      }).addTo(map);

      this.pathLine = L.polyline(waypoints, {
        color: '#df1f2d',
        weight: 1,
        opacity: 0.3,
        dashArray: '6 6'
      }).addTo(map);

      this.startPatrol();
    }

    startPatrol() {
      this.tick = setInterval(() => this.update(), 200);
    }

    update() {
      const target = this.waypoints[this.currentIndex + this.direction];
      if (!target) {
        this.direction *= -1;
        return;
      }

      const current = this.marker.getLatLng();
      const dx = target[1] - current.lng;
      const dy = target[0] - current.lat;
      const dist = Math.sqrt(dx*dx + dy*dy);

      if (dist < DRONE_SPEED * 2) {
        this.currentIndex += this.direction;
        if (this.currentIndex >= this.waypoints.length - 1) this.direction = -1;
        if (this.currentIndex <= 0) this.direction = 1;
      } else {
        const newLat = current.lat + (dy / dist) * DRONE_SPEED;
        const newLng = current.lng + (dx / dist) * DRONE_SPEED;
        this.marker.setLatLng([newLat, newLng]);
        this.spotlight.setLatLng([newLat, newLng]);
      }

      this.checkSpotting();
    }

    checkSpotting() {
      // Stub: check against player positions
      // Will integrate with GPS tracking system
      const center = this.marker.getLatLng();
      // When player system is ready:
      // Object.values(playerPositions).forEach(player => {
      //   if (center.distanceTo(player.pos) < DRONE_SPOT_RADIUS) {
      //     this.triggerAlert(player);
      //   }
      // });
    }

    triggerAlert(player) {
      if (this.alerted) return;
      this.alerted = true;
      this.spotlight.setStyle({ fillColor: '#ff0000', fillOpacity: 0.4 });

      // Broadcast to enemy squad
      const event = new CustomEvent('droneAlert', {
        detail: { droneId: this.id, position: this.marker.getLatLng(), spotted: player }
      });
      document.dispatchEvent(event);

      // Visual flare
      L.circleMarker(this.marker.getLatLng(), {
        radius: 40,
        color: '#df1f2d',
        fillColor: '#df1f2d',
        fillOpacity: 0.6
      }).addTo(this.map).bindPopup('⚠️ DRONE ALERT — ENEMY SPOTTED').openPopup();

      setTimeout(() => { this.alerted = false; this.spotlight.setStyle({ fillColor: '#df1f2d', fillOpacity: 0.15 }); }, 10000);
    }

    destroy() {
      clearInterval(this.tick);
      this.map.removeLayer(this.marker);
      this.map.removeLayer(this.spotlight);
      this.map.removeLayer(this.pathLine);
    }

    hijack() {
      this.spotlight.setStyle({ color: '#00a9c7', fillColor: '#00a9c7' });
      this.marker.setIcon(L.divIcon({
        className: 'patrol-drone hijacked',
        html: '🛸✓',
        iconSize: [32, 32],
        iconAnchor: [16, 16]
      }));
      // Now spots enemies instead of players
    }
  }

  // ============ SNIPER NEST ============
  class SniperNest {
    constructor(id, position, map) {
      this.id = id;
      this.position = position;
      this.map = map;
      this.lastShot = 0;
      this.targets = [];

      this.marker = L.marker(position, {
        icon: L.divIcon({
          className: 'sniper-nest',
          html: '🔴',
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        })
      }).addTo(map);

      this.range = L.circle(position, {
        radius: SNIPER_RANGE,
        color: '#df1f2d',
        fillColor: '#df1f2d',
        fillOpacity: 0.05,
        weight: 1
      }).addTo(map);

      // Laser sight line
      this.laser = L.polyline([position, position], {
        color: '#ff0000',
        weight: 2,
        opacity: 0.6,
        dashArray: '10 5'
      }).addTo(map);
    }

    aimAt(targetPos) {
      this.laser.setLatLngs([this.position, targetPos]);
    }

    canFire() {
      return Date.now() - this.lastShot > SNIPER_COOLDOWN;
    }

    fire(target) {
      if (!this.canFire()) return false;
      this.lastShot = Date.now();

      // Laser flash
      this.laser.setStyle({ opacity: 1, weight: 4 });
      setTimeout(() => this.laser.setStyle({ opacity: 0.6, weight: 2 }), 300);

      // Shot tracer
      const tracer = L.polyline([this.position, target], {
        color: '#ffff00',
        weight: 3,
        opacity: 0.8
      }).addTo(this.map);
      setTimeout(() => this.map.removeLayer(tracer), 500);

      // Hit effect
      L.circleMarker(target, {
        radius: 15,
        color: '#df1f2d',
        fillColor: '#df1f2d',
        fillOpacity: 0.8
      }).addTo(this.map);

      return true;
    }

    destroy() {
      this.map.removeLayer(this.marker);
      this.map.removeLayer(this.range);
      this.map.removeLayer(this.laser);
    }
  }

  // ============ TRAP SYSTEM ============
  class TrapSystem {
    constructor(map) {
      this.map = map;
      this.traps = [];
    }

    placeMine(position, team) {
      const mine = L.circleMarker(position, {
        radius: 4,
        color: team === 'alpha' ? '#00a9c7' : '#ff8b45',
        fillColor: team === 'alpha' ? '#00a9c7' : '#ff8b45',
        fillOpacity: 0.8,
        weight: 0
      }).addTo(this.map);

      const trigger = L.circle(position, {
        radius: 2, // 2 meters
        color: 'transparent',
        fillColor: 'transparent',
        fillOpacity: 0
      }).addTo(this.map);

      this.traps.push({ type: 'mine', position, team, mine, trigger, armed: true });
      return mine;
    }

    placeTripwire(pos1, pos2, team) {
      const wire = L.polyline([pos1, pos2], {
        color: team === 'alpha' ? '#00a9c7' : '#ff8b45',
        weight: 2,
        opacity: 0.4,
        dashArray: '4 4'
      }).addTo(this.map);

      this.traps.push({ type: 'tripwire', pos1, pos2, team, wire, armed: true });
      return wire;
    }

    placeC4(position, team) {
      const c4 = L.marker(position, {
        icon: L.divIcon({
          className: 'c4-charge',
          html: '💣',
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        })
      }).addTo(this.map);

      this.traps.push({ type: 'c4', position, team, c4, armed: true, detonated: false });
      return c4;
    }

    detonateC4(trapId) {
      const trap = this.traps.find(t => t.type === 'c4' && !t.detonated);
      if (!trap) return;

      trap.detonated = true;
      const explosion = L.circleMarker(trap.position, {
        radius: 60,
        color: '#ff6600',
        fillColor: '#ff6600',
        fillOpacity: 0.6
      }).addTo(this.map);

      // Shockwave rings
      for (let i = 1; i <= 3; i++) {
        setTimeout(() => {
          L.circle(trap.position, {
            radius: 30 * i,
            color: '#ff6600',
            weight: 2,
            opacity: 1 - i * 0.25
          }).addTo(this.map);
        }, i * 200);
      }

      setTimeout(() => this.map.removeLayer(explosion), 2000);
    }

    checkProximity(playerPos) {
      this.traps.forEach(trap => {
        if (!trap.armed) return;
        if (trap.type === 'mine') {
          const dist = this.map.distance(playerPos, trap.position);
          if (dist < 2) {
            this.triggerMine(trap);
          }
        }
      });
    }

    triggerMine(trap) {
      trap.armed = false;
      this.map.removeLayer(trap.mine);
      this.map.removeLayer(trap.trigger);

      L.circleMarker(trap.position, {
        radius: 30,
        color: '#df1f2d',
        fillColor: '#df1f2d',
        fillOpacity: 0.7
      }).addTo(this.map).bindPopup('💥 MINE DETONATED').openPopup();

      // Damage event
      const event = new CustomEvent('mineTriggered', {
        detail: { position: trap.position, team: trap.team }
      });
      document.dispatchEvent(event);
    }

    disarmMine(position, team) {
      const trap = this.traps.find(t =>
        t.type === 'mine' &&
        t.armed &&
        this.map.distance(position, t.position) < 3
      );
      if (!trap) return false;

      trap.armed = false;
      this.map.removeLayer(trap.mine);
      this.map.removeLayer(trap.trigger);

      L.marker(trap.position, {
        icon: L.divIcon({
          className: 'disarmed-mine',
          html: '✓',
          iconSize: [16, 16],
          iconAnchor: [8, 8]
        })
      }).addTo(this.map).bindPopup('MINE DISARMED').openPopup();

      return true;
    }
  }

  // ============ HAZARD SPAWNER ============
  class HazardSpawner {
    constructor(map) {
      this.map = map;
      this.hazards = [];
    }

    spawnGasZone(center, radius = 50, duration = 300000) {
      const gas = L.circle(center, {
        radius,
        color: '#8bc34a',
        fillColor: '#8bc34a',
        fillOpacity: 0.25,
        weight: 1,
        dashArray: '8 8'
      }).addTo(this.map).bindPopup('☠️ POISON GAS — GAS MASK REQUIRED');

      // Pulsing animation
      let pulse = 0;
      const pulseInterval = setInterval(() => {
        pulse += 0.1;
        const newRadius = radius + Math.sin(pulse) * 5;
        gas.setRadius(newRadius);
      }, 500);

      this.hazards.push({ type: 'gas', zone: gas, interval: pulseInterval });

      setTimeout(() => {
        clearInterval(pulseInterval);
        this.map.removeLayer(gas);
      }, duration);

      return gas;
    }

    spawnEMP(center, radius = 100, duration = 60000) {
      const emp = L.circle(center, {
        radius,
        color: '#9c27b0',
        fillColor: '#9c27b0',
        fillOpacity: 0.15,
        weight: 2
      }).addTo(this.map).bindPopup('⚡ EMP FIELD — ELECTRONICS DISABLED');

      // Static flicker
      let flicker = setInterval(() => {
        emp.setStyle({ fillOpacity: 0.1 + Math.random() * 0.1 });
      }, 200);

      this.hazards.push({ type: 'emp', zone: emp, interval: flicker });

      setTimeout(() => {
        clearInterval(flicker);
        this.map.removeLayer(emp);
      }, duration);

      return emp;
    }

    spawnDecoyBeacon(position, team) {
      const beacon = L.marker(position, {
        icon: L.divIcon({
          className: 'decoy-beacon',
          html: '📡',
          iconSize: [24, 24],
          iconAnchor: [12, 12]
        })
      }).addTo(this.map).bindPopup('📡 SIGNAL BEACON — VERIFY BEFORE APPROACHING');

      // Fake SOS ping
      const ping = L.circleMarker(position, {
        radius: 20,
        color: '#df1f2d',
        fillColor: 'transparent',
        weight: 2
      }).addTo(this.map);

      let pingRadius = 20;
      const pingAnim = setInterval(() => {
        pingRadius += 2;
        ping.setRadius(pingRadius);
        ping.setStyle({ opacity: 1 - (pingRadius / 200) });
      }, 200);

      setTimeout(() => {
        clearInterval(pingAnim);
        this.map.removeLayer(ping);
      }, 5000);

      this.hazards.push({ type: 'decoy', marker: beacon });
      return beacon;
    }
  }

  // ============ NOISE SYSTEM ============
  class NoiseSystem {
    constructor(map) {
      this.map = map;
      this.sources = [];
    }

    emitNoise(position, radius, type = 'unknown') {
      const icons = {
        walk: '👣',
        run: '👣👣',
        shot: '🔫',
        vehicle: '🚗',
        explosion: '💥'
      };

      const colors = {
        walk: '#8d6e63',
        run: '#ff9800',
        shot: '#df1f2d',
        vehicle: '#795548',
        explosion: '#ff5722'
      };

      const noise = L.circle(position, {
        radius,
        color: colors[type] || '#888',
        fillColor: colors[type] || '#888',
        fillOpacity: 0.1,
        weight: 1,
        dashArray: '4 4'
      }).addTo(this.map);

      // Fade out
      let opacity = 0.1;
      const fade = setInterval(() => {
        opacity -= 0.01;
        if (opacity <= 0) {
          clearInterval(fade);
          this.map.removeLayer(noise);
        } else {
          noise.setStyle({ fillOpacity: opacity, opacity: opacity * 2 });
        }
      }, 100);

      this.sources.push({ noise, type, position, radius });
    }

    // Direction indicator for enemies in range
    showDirectionIndicator(enemyPos, noisePos, noiseType) {
      const angle = Math.atan2(
        noisePos.lng - enemyPos.lng,
        noisePos.lat - enemyPos.lat
      ) * 180 / Math.PI;

      // Add directional arrow on enemy's HUD
      const event = new CustomEvent('noiseDetected', {
        detail: { angle, type: noiseType, distance: this.map.distance(enemyPos, noisePos) }
      });
      document.dispatchEvent(event);
    }
  }

  // ============ LOOT SYSTEM ============
  class LootSystem {
    constructor(map) {
      this.map = map;
      this.drops = [];
    }

    spawnDrop(position, items) {
      const drop = L.marker(position, {
        icon: L.divIcon({
          className: 'loot-drop',
          html: '?',
          iconSize: [28, 28],
          iconAnchor: [14, 14]
        })
      }).addTo(this.map).bindPopup(`🎒 LOOT: ${items.join(', ')}`);

      // Pulse animation
      let pulse = 20;
      const ring = L.circle(position, {
        radius: pulse,
        color: '#ffd700',
        fillColor: 'transparent',
        weight: 2
      }).addTo(this.map);

      const pulseInterval = setInterval(() => {
        pulse += 1;
        ring.setRadius(pulse);
        ring.setStyle({ opacity: 1 - (pulse / 60) });
      }, 100);

      setTimeout(() => {
        clearInterval(pulseInterval);
        this.map.removeLayer(ring);
      }, 3000);

      this.drops.push({ position, items, marker: drop });
      return drop;
    }
  }

  // ============ MANAGER ============
  class AIThreatManager {
    constructor(map) {
      this.map = map;
      this.drones = [];
      this.snipers = [];
      this.traps = new TrapSystem(map);
      this.hazards = new HazardSpawner(map);
      this.noise = new NoiseSystem(map);
      this.loot = new LootSystem(map);
    }

    spawnDrone(waypoints) {
      const drone = new PatrolDrone(`drone-${this.drones.length}`, waypoints, this.map);
      this.drones.push(drone);
      return drone;
    }

    spawnSniper(position) {
      const sniper = new SniperNest(`sniper-${this.snipers.length}`, position, this.map);
      this.snipers.push(sniper);
      return sniper;
    }

    clearAll() {
      this.drones.forEach(d => d.destroy());
      this.snipers.forEach(s => s.destroy());
      this.drones = [];
      this.snipers = [];
    }
  }

  // ============ EXPORTS ============
  window.AIThreats = {
    PatrolDrone,
    SniperNest,
    TrapSystem,
    HazardSpawner,
    NoiseSystem,
    LootSystem,
    AIThreatManager
  };

})();
